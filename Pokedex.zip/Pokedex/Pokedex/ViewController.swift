//
//  ViewController.swift
//  Pokedex
//
//  Created by Mario Chávez on 16/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .red

    }
    
}

